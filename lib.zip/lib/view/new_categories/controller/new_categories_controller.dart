import 'package:get/get.dart';

class NewCategoriesController extends GetxController{

  RxInt selectedIndex = 0.obs;

}