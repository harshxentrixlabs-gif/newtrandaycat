import 'package:get/get.dart';

import '../../../utils/common/app_bottom_sheet.dart';

class OtpController extends GetxController{




}