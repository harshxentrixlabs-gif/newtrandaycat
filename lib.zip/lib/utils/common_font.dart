class AppFont{



  static const String medium = 'Medium';
  static const String semiBold = 'SemiBold';
  static const String bold = 'Bold';
  static const String regular = 'Regular';
}